# 🚀 Hero Dashboard v4.0

This is an advanced interactive personal dashboard built by Hero 💪.

## Features:
- 🔔 Smart Reminder System
- 📊 Weekly HeroScore Chart
- 🎙️ Voice Input with Web Speech API
- 🧠 Smart Productivity Advice
- 📄 PDF Report Export
- ☁️ Firebase Cloud Sync Ready

## Live Demo
[https://yourgithubusername.github.io/hero-dashboard](#)

## Setup
1. Clone the repo or download ZIP
2. Open `index.html` in your browser
3. To enable Firebase, configure your `firebase.js` with credentials
